public class ArrayEvenEx
{ 
   public static void main(String[] args)
   {
      int elements[] = {1,2,3,4,5,6,7,8,9};
      for(int i=0;i<elements.length;i++) 
      {
          if(elements[i]%2==0) 
          System.out.println("the even number is ="+elements[i]);
      }
          
          
   }
}