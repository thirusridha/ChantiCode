class BiddestNumber
{
  public static void main (String [] args)
  {
    int elements[] ={2,4,666,8,89,100,120};
    int bigg = elements[0];
     for(int i=1;i<elements.length;i++)
     {
       if(bigg < elements[i])
       {  
           bigg = elements [i];
        }

     }
           System.out.println("biggest number is ="+ bigg);
  
  }
}