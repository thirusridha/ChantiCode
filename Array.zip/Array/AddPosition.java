 class AddPosition
{
  public static void main (String [] args)
  {
    int elements[] ={1,2,4,5,8,6,9};
     for(int i=0;i<elements.length;i++)
     {
       if(i%2==0)
         System.out.println( elements [i] +" ");
     }

  }
}