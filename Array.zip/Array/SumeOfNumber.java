public class SumeOfNumber
{
   
   public static void main(String[] args)
   {
      int[] elements = {11, 22, 32, 49, 57, 61, 77, 89,99};
      int sum = 0;

      for(int i=0;i<elements.length;i++)
      {    
          sum = sum + elements[i];
      }

        System.out.println("sum = " + sum);
       
     
    
       
      
   }
}