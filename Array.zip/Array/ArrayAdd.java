public class ArrayAdd
{ 
   public static void main(String[] args)
   {
      int elements[] = {1,3,5,7,9,11,13};
      for(int i=0;i<elements.length;i++) 
      {
          if(elements[i]%2!=0){ 
           System.out.print(elements[i]+" ");
   	 // System.out.print(" ");
          }
      } 
        
   }
}