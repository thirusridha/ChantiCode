0import java.util.*; 
class RightRotate
{
  public static void main (String [] args)
  {
    int arr[] = {1,2,3,4,5,6,7};
     Scanner sc = new Scanner (System.in);
         System.out.println("Enter the number");
       int num = sc.nextInt();
     int element[] = new int[arr.length];
     int j=0;
      while(num>arr.length)
      {
         num = num-arr.length;
      }
      for(int i=num;i<arr.length-num;i++)
      {
          element[j] = arr[i];
          j++;
      }
        for(int i=0;i<num;i++)
        {
           element[j] = arr[i];
           j++;
        }
          for(int i=0;i<arr.length;i++)
          {
             System.out.print(element[i]+" ");
          }
      
   
  }
}