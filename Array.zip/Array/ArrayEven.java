public class ArrayEven
{ 
   public static void main(String[] args)
   {
      int elements[] = {1,3,5,7,9,11,13};
      for(int i=0;i<elements.length;i++) 
      {
          if(elements[i]%2==0) 
          System.out.println("the number is a even");
      }
          
          System.out.println("the number is not a even");
   }
}