class ArrayEx
{
   public static void main(String[] args)
   {
      int[] a = new int[5];

      System.out.println(a);  //[I@hex-dec-no
      System.out.println(a[0]);  //0 
      System.out.println(a[1]);  //0
      System.out.println(a[2]);  //0
      System.out.println(a[3]);  //0
      System.out.println(a[4]);  //0
      System.out.println(a[5]);  //AIOOBE
   }
}