class SmallestNumber
{
  public static void main (String [] args)
  {
    int elements[] ={99,333,456,2,45,3,7,9,99};
    int small =elements[0];
     for(int i=1;i<elements.length;i++)
     {
       if(small>elements[i])
       {  
           small = elements [i];
        }

     }
           System.out.println("smallest number is ="+ small);
  
  }
}