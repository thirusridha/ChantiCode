public class ArrayAdd1
{ 
   public static void main(String[] args)
   {
      int elements[] = {2,4,6,8,};
      int v =0;
      for(int i=0;i<elements.length;i++) 
      {
          if(elements[i]%2!=0){ 

            v =1;
           System.out.print(elements[i]+" ");
   
          }
      }
       if(v==0)
         System.out.println("it is not a add   number"); 
        
   }
}