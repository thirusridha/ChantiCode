class ArrayEx3
{
  public static void main (String [] args)
  {
    int arr[] = {1,2,3,4,5,6,7};
     if(arr%2==0)
     System.out.println("")
  }
}