import java.util.*;
class AmstrongBitNumber
{
  public static void main (String [] args)
  {
    
        
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter start number: ");
       int kutty = sc.nextInt();
       System.out.println("Enter end number: ");
       int chinni = sc.nextInt();
        
       System.out.println("Amstrong numbere are: ");
      for(int i=kutty; i<=chinni; i++)
      {
        int num = i;
        int res = 0;
    while(num !=0)
     {
      int rem = num  %10;
      res = res +(rem*rem*rem) ;
      num = num /10;
      }
        if(res == i)
        System.out.print(" "+ res);
       }
        
    
  }
}