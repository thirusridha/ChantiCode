import java.util.*;
class AmstrongNumber
{
  public static void main (String [] args)
  {
    int  temp =0,rem, rev = 0;
        
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter the number");
       int num = sc.nextInt();
        temp = num;
    while(temp !=0)
     {
      rem = temp %10;
      rev = rev +(rem*rem*rem) ;
      temp = temp /10;
      }
        if(num == rev)
        System.out.print("its a amstrong number :");
        else
         System.out.print("its not a amstrong number :");
        
    
  }
}