import java.util.*;
class SwitchCaseEx
{
  public static void main (String [] args )
  {
    Scanner sc = new Scanner (System.in);
     System.out.print("enter a number");
     int num = sc.nextInt();
     switch(num)
     {
          case 1:
            System.out.println("you enter num is : 1");
            break;
          case 2:
            System.out.println("you enter num is : 2");
            break;
          case 3:
            System.out.println("you enter num is : 3");
            break;
          case 4:
            System.out.println("you enter num is : 4");
            break;
          default :
            System.out.println("Ivalide value");
     }

  }
}