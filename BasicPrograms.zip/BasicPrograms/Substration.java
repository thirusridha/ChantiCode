class Substration
{
  public static void main (String [] args )
  {
    int a = 13, b = 7, c = 14;
    int d = a - b - c;
    System. out.println("Substration number is ..."+d);
  }
   
}