class Vote
{
  public static void main (String [] args)
  {
    int age = 19 ;
    if (age>=18)
     System.out.println("eligibule for vote");
    else
     System.out.println("not eligibule for vote");
  }
}