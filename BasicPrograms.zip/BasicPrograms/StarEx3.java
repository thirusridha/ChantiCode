import java.util.*;
class StarEx3
{
  public static void main (String [] args)
  {
        Scanner sc = new Scanner(System.in);
         System.out.println("Enter your number");
      int num = sc.nextInt();
      for(int i=num;i>0;i--)
      {
          for(int j=1 ;j<=num;j++)
          {
              if(i>j)
                System.out.print(" ");
              else
                System.out.print("*");
          }
	System.out.println();
      }
          
         
  }
}