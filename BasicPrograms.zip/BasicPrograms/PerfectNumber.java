import java.util.*;
class PerfectNumber
{
  public static void main (String [] args)
  {
     int num, sume = 0;
     Scanner sc = new Scanner (System.in);
      System.out.println("enter the number :");
       num = sc. nextInt();
        for(int i = 1; i<num; i++)
        {
           if(num % i==0)
            sume = sume + i;
        }
            if(sume==num)
               System.out.println("given number is a perfect");
            else
               System.out.println("given number is not a perfect");
          
          

  }
}