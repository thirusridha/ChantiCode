import java.util.*;
class SwitchCaseEx1
{
  public static void main (String [] args)
  {
    System.out.println("1 idlie-20 \n2 vada-25 \n3 dosa-30 \n4 puri-35");
      Scanner sc = new Scanner(System.in);
        System.out.println("please enter your choice :");
    int num = sc.nextInt();
    switch(num)
    {
        case 1:
          System.out.println("How many plate idlie you want ");
        int num2 = sc.nextInt();
          System.out.println("Amount :"+(num2*20));
          System.out.println("thank you");

         
        case 2:
          System.out.println("How many plate vada you want");
         num2 = sc.nextInt();
          System.out.println("Amount :"+(num2*25));
          System.out.println("thank you");
        
        case 3:
          System.out.println("How many plate dosa you want");
         num2 = sc.nextInt();
          System.out.println("Amount :"+(num2*30));
          System.out.println("thank you");
        
        case 4:
          System.out.println("How many plate puri you want");
         num2 = sc.nextInt();
          System.out.println("Amount :"+(num2*35));
          System.out.println("thank you");
         default :
          System.out.println("Invalied number");
    }    
  }
}