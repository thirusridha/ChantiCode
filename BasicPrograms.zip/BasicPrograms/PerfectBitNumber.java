import java.util.*;
class PerfectBitNumber
{
  public static void main (String [] args)
  {
      int  sum ;
       Scanner sc = new Scanner (System.in);
          System.out.print("minimum values :");
             int min = sc.nextInt();
          System.out.print("maximum values :");
             int max = sc.nextInt();
           if(min<max)
          System.out.print("perfect bitween number :"); 
          
        for(int num=min; num<=max; num++) 
       {
           sum = 0;
         for(int i=1; i<num; i++)
         {
           if(num%i ==0)
           sum = sum + i;
         }
           
             if(sum ==num )
             System.out.print(num +" ");
       }
   }
}