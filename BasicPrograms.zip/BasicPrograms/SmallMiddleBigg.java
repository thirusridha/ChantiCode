class SmallMiddleBigg
{
  public static void main (String [] args)
  {
     int num = 100;
      if(num>=0 && num<=50)
        System.out.println("it is a small numbver");
      else if(num>=51 && num<=75)
        System.out.println("it is a middle number");
      else if(num>=76 && num<=100)
        System.out.println("it is a bigg number");
      else
        System.out.println(" defalt value");
  }
}