class BiggOfThreeNumber
{
  public static void main (String [] args)
  {
   int a = 13,b = 11,c = 5;
   if(a>b)
   {
     if(a>c)
      System.out.println(" a is bigg numbetr");
     else
      System.out.println(" c is a bigg number");
   }
     else
     {
      if(b>c)
      
       System.out.println(" b is bigg number");
      else
       System.out.println("c is bigg number");
      }
  }
}