class ReversNumber
{
  public static void main (String [] args)
  {
    int num = 123, rev = 0;
    int temp = num;
      while(temp!=0)
      { 
       int rem = temp%10;
           rev = rev*10 + rem;
           temp = temp/10;
      }
         System.out.println("the revers number "+num+" is "+rev);
   }
    
}