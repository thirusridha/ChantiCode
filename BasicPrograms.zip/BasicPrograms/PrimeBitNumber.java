class PrimeBitNumber
{
  public static void main(String [] args)
  {
    int num = 100;
    for(int i=1;i<=num;i++)
    {
     int count = 0; 
      for(int j=2;j<i;j++)
      {
        if (i%j==0)
          count=1;
      }
        if( count==0)
        {  
          System.out.println(i+"  ");
        }
    }
  }
}