import java.util.Scanner;
class AdditionEx1
{
  public static void main (String [] args)
  {
       Scanner sc =new Scanner(System.in);
       System.out.print("Enter first number : ");	
       int num1 =sc.nextInt();
       System.out.print("Enter second number : ");
       int num2=sc.nextInt();
    //   System.out.print("num1"="+num1+" and "num2"="+num2);//(num1 = 5 and num2 = 2)
       System.out.print("num1 = "+num1+" and num2 = "+num2);//
  }  
}