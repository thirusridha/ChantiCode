class Palindrome
{
  public static void main (String [] args)
  {
    int num = 353, rev = 0;
    int temp = num;
      while(temp!=0)
      { 
       int rem = temp%10;
           rev = rev*10 + rem;
           temp = temp/10;
      }
      if(num == rev)
    
         System.out.println(" it is  a palindrome");
      else

         System.out.println(" it is not  a palindrome");
   }
    
}