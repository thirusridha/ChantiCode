class SwappingWithOutVariable
{
  public static void main(String [] args)
  {
    int a = 2, b = 3;
         a = a * b; //6
         b = a / b;//2
         a = a / b;//
     System.out.print("a = " + a + ", b = " + b);
  }
}