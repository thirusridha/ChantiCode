import java.util.*;
class SumeEx
{
  public static void main(String [] args)
  {
       Scanner sc = new Scanner (System.in);
         System.out.println("Enter the number");
       int num = sc.nextInt();
       int sume = 0;
        for(int i=1;i<=num;i++)
        {
           sume = sume + (i);
        }
          System.out.print("the sume of number is :"+sume);
  }
}